package com.enigma.farsilandtv

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

internal fun watchUrl(value: String): String? {
    if (value.length > 1024) return null
    val uri = Uri.parse(value)
    val path = uri.encodedPath.orEmpty().trimEnd('/')
    val host = uri.host?.lowercase()?.removePrefix("www.")
    if (uri.scheme != "https" || host != "farsiland.com" || uri.userInfo != null ||
        uri.port !in listOf(-1, 443) || !Regex("/(episodes|movies)/[^/]+").matches(path)) return null
    return "https://farsiland.com$path/"
}

internal fun videoQuality(value: Int) = value.takeIf { it in setOf(480, 720, 1080, 1440, 2160) }

internal data class WatchItem(val url: String, val title: String, val poster: String?, val next: NextEpisode?) {
    fun json() = JSONObject().put("url", url).put("title", title).put("poster", poster)
        .put("next", next?.url).put("nextTitle", next?.title)

    companion object {
        fun fromPage(page: String, details: JSONObject): WatchItem? {
            val url = watchUrl(page) ?: return null
            val fallbackTitle = Uri.parse(url).lastPathSegment.orEmpty().replace('-', ' ')
            val title = details.optString("title").trim().take(180).ifBlank { fallbackTitle }
            val photo = details.optString("poster")
            val uri = Uri.parse(photo)
            val poster = photo.takeIf {
                it.length <= 1024 && uri.scheme == "https" && uri.userInfo == null && uri.port in listOf(-1, 443) &&
                    uri.host?.lowercase()?.removePrefix("www.") == "farsiland.com" &&
                    uri.encodedPath.orEmpty().startsWith("/wp-content/uploads/")
            }
            val next = watchUrl(details.optString("next"))
                ?.takeIf { it != url && url.contains("/episodes/") && it.contains("/episodes/") }
                ?.let { NextEpisode(it, details.optString("nextTitle").trim().take(180)) }
            return WatchItem(url, title, poster, next)
        }
    }
}

internal data class NextEpisode(val url: String, val title: String) {
    fun asWatchItem(poster: String?) = WatchItem(url, title.ifBlank {
        Uri.parse(url).lastPathSegment.orEmpty().replace('-', ' ')
    }, poster, null)
}

internal data class WatchProgress(val item: WatchItem, val position: Int, val duration: Int, val quality: Int?) {
    fun json() = item.json().put("position", position).put("duration", duration).put("quality", quality)
}

internal class PlaybackHistory(context: Context) {
    private val prefs = context.getSharedPreferences("watch_history", Context.MODE_PRIVATE)
    private var entries = read()

    fun forHome() = JSONArray(entries.map { entry ->
        JSONObject().put("url", entry.item.url).put("title", entry.item.title).put("poster", entry.item.poster)
            .put("position", entry.position).put("duration", entry.duration)
    })

    fun find(url: String) = entries.firstOrNull { it.item.url == url }

    fun remember(progress: WatchProgress) {
        if (entries.firstOrNull() == progress) return
        save(listOf(progress) + entries.filter { it.item.url != progress.item.url })
    }

    fun complete(item: WatchItem, quality: Int?) {
        val next = item.next?.let {
            find(it.url) ?: WatchProgress(it.asWatchItem(item.poster), 0, 0, quality)
        }
        save(listOfNotNull(next) + entries.filter { it.item.url != item.url && it.item.url != next?.item?.url })
    }

    private fun save(updated: List<WatchProgress>) {
        entries = updated.take(MAX_ITEMS)
        prefs.edit().putString(KEY, JSONArray(entries.map(WatchProgress::json)).toString()).apply()
    }

    private fun read(): List<WatchProgress> {
        val data = runCatching { JSONArray(prefs.getString(KEY, "[]")) }.getOrElse { JSONArray() }
        return (0 until minOf(data.length(), MAX_ITEMS)).mapNotNull { index ->
            val record = data.optJSONObject(index) ?: return@mapNotNull null
            val item = WatchItem.fromPage(record.optString("url"), record) ?: return@mapNotNull null
            val duration = record.optInt("duration").coerceIn(0, MAX_DURATION)
            val position = record.optInt("position").coerceIn(0, duration)
            WatchProgress(item, position, duration, videoQuality(record.optInt("quality")))
        }
    }

    companion object {
        const val MAX_DURATION = 24 * 60 * 60
        private const val KEY = "recent"
        private const val MAX_ITEMS = 8
    }
}
